const { fetchCountries } = require('../services/countryService');

exports.random = async (_, res) => {
  try {
    const list = await fetchCountries();
    const item = list[Math.floor(Math.random() * list.length)];
    res.json(item);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const moment = require('moment-timezone');
const { fetchCountry } = require('../services/countryService');

exports.getTime = async (req, res) => {
  try {
    const c = await fetchCountry(req.params.name);
    if (!c) return res.status(404).json({ error: 'Country not found' });
    const tz = (c.timezones && c.timezones.length) ? c.timezones[0] : 'UTC';
    const time = moment().tz(tz).format('YYYY-MM-DD HH:mm:ss');
    res.json({ country: c.name.common, timezone: tz, time });
  } catch (err) {
    res.status(500).json({ error: 'Failed to get time', detail: err.message });
  }
};

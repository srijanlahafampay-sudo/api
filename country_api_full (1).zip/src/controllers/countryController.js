const { fetchCountries, fetchCountry } = require('../services/countryService');

exports.all = async (_, res) => {
  try {
    const data = await fetchCountries();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch countries', detail: err.message });
  }
};

exports.one = async (req, res) => {
  try {
    const c = await fetchCountry(req.params.name);
    if (!c) return res.status(404).json({ error: 'Country not found' });
    res.json(c);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch country', detail: err.message });
  }
};

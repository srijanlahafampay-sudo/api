const { fetchCountry } = require('../services/countryService');

exports.compare = async (req, res) => {
  try {
    const { A, B } = req.query;
    if (!A || !B) return res.status(400).json({ error: 'Provide A and B query params' });
    const a = await fetchCountry(A);
    const b = await fetchCountry(B);
    if (!a || !b) return res.status(404).json({ error: 'One or both countries not found' });
    res.json({
      A: { name: a.name.common, population: a.population || null, area: a.area || null, region: a.region || null },
      B: { name: b.name.common, population: b.population || null, area: b.area || null, region: b.region || null }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

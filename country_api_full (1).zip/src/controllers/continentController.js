const { fetchCountries } = require('../services/countryService');

exports.listByRegion = async (req, res) => {
  try {
    const region = req.params.region.toLowerCase();
    const list = await fetchCountries();
    const filtered = list.filter(c => (c.region || '').toLowerCase() === region);
    if (!filtered.length) return res.status(404).json({ error: 'No countries found for that region' });
    res.json(filtered);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

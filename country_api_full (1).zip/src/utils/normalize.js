/**
 * Normalize and merge datasets
 * rest: RESTCountries array
 * popList: array from countriesnow.space/population API (optional)
 */
function findPopulationFromList(name, popList) {
  if (!popList || !Array.isArray(popList)) return null;
  const lower = name.toLowerCase();
  const found = popList.find(p => (p.country || '').toLowerCase() === lower);
  if (!found) return null;
  // populationCounts is an array; take last available value
  const counts = found.populationCounts || [];
  if (!counts.length) return null;
  return counts[counts.length - 1].value || null;
}

module.exports = {
  combine(rest, popList) {
    return rest.map(country => {
      const common = country.name?.common || country.name;
      const popFromList = findPopulationFromList(common, popList);
      const population = popFromList || country.population || null;
      return {
        name: country.name,
        cca2: country.cca2,
        cca3: country.cca3,
        capital: country.capital || [],
        region: country.region || country.subregion || null,
        population,
        area: country.area || null,
        timezones: country.timezones || [],
        flags: country.flags || {},
        maps: country.maps || {},
        currencies: country.currencies || {}
      };
    });
  }
};

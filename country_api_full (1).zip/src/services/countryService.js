const axios = require('axios');
const cache = require('./cache');
const normalize = require('../utils/normalize');
const path = require('path');
const fs = require('fs');

const REST = 'https://restcountries.com/v3.1/all';
const POP = 'https://countriesnow.space/api/v0.1/countries/population';
const LOCAL_FALLBACK = path.join(__dirname, '..', 'data', 'localFallback.json');

async function fetchPrimary() {
  const res = await axios.get(REST, { timeout: 10000 });
  return res.data;
}

async function fetchPopulationList() {
  try {
    const res = await axios.get(POP, { timeout: 10000 });
    return res.data?.data || [];
  } catch (err) {
    return [];
  }
}

function loadLocalFallback() {
  if (!fs.existsSync(LOCAL_FALLBACK)) return [];
  try {
    const raw = fs.readFileSync(LOCAL_FALLBACK, 'utf8');
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

async function fetchCountries() {
  const cached = cache.get('countries_all');
  if (cached) return cached;

  let restData = [];
  let popList = [];
  try {
    restData = await fetchPrimary();
  } catch (err) {
    // if primary fails, use local fallback
    restData = loadLocalFallback();
  }

  try {
    popList = await fetchPopulationList();
  } catch {}

  const combined = normalize.combine(restData, popList);
  cache.set('countries_all', combined);
  return combined;
}

async function fetchCountry(name) {
  const list = await fetchCountries();
  if (!name) return null;
  const lower = name.toLowerCase();
  return list.find(c => {
    const common = (c.name?.common || '').toLowerCase();
    const official = (c.name?.official || '').toLowerCase();
    const cca2 = (c.cca2 || '').toLowerCase();
    const cca3 = (c.cca3 || '').toLowerCase();
    const alt = [common, official].map(x => x.toLowerCase());
    return common === lower || official === lower || cca2 === lower || cca3 === lower || alt.includes(lower);
  }) || null;
}

module.exports = { fetchCountries, fetchCountry };

const express = require('express');
const router = express.Router();
const controller = require('../controllers/timeController');

router.get('/:name', controller.getTime);

module.exports = router;

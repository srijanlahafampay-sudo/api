const express = require('express');
const router = express.Router();
const controller = require('../controllers/continentController');

router.get('/:region', controller.listByRegion);

module.exports = router;

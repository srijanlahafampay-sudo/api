const express = require('express');
const router = express.Router();
const controller = require('../controllers/randomController');

router.get('/', controller.random);

module.exports = router;

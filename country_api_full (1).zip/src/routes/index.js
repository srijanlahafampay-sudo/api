const express = require('express');
const router = express.Router();

router.use('/countries', require('./country'));
router.use('/country', require('./country'));
router.use('/time', require('./time'));
router.use('/compare', require('./compare'));
router.use('/random', require('./random'));
router.use('/continent', require('./continents'));

router.get('/', (_, res) => res.json({ ok: true, endpoints: ['/countries', '/country/:name', '/time/:name', '/compare', '/random', '/continent/:region'] }));

module.exports = router;

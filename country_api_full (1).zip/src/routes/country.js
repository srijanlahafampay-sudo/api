const express = require('express');
const router = express.Router();
const controller = require('../controllers/countryController');

router.get('/', controller.all);
router.get('/:name', controller.one);

module.exports = router;
